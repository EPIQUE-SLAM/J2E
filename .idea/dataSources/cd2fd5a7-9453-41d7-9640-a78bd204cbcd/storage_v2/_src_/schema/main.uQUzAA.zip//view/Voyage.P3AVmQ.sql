CREATE VIEW Voyage ( id_voyage, type, date,lieu_depart, lieu_arrivee, num_transport)
As

Select Distinct (D.id_voyage), D.Methode, D.date, D.depart, D.arrivee,

            case D.methode
                when 'avion' then (Select Va.code_avion from VoyageEnAvion Va join Dossier D on Va.id_avion = D.id_Voyage)
                when 'train' then (Select Vt.code_train from VoyageEnTrain Vt join Dossier D on Vt.id_train = D.id_Voyage)
                when 'bus' then (Select Vb.code_bus from VoyageEnBus Vb join Dossier D on Vb.id_bus = D.id_Voyage)
                end
                as num_transport

from Dossier D;

