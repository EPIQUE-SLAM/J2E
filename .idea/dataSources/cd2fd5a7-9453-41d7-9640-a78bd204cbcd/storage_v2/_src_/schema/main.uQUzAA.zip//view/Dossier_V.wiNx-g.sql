CREATE VIEW Dossier_V( reference_dossier, voyage,date, idPassager)
As
Select D.id_dossier, D.id_voyage, D.date, D.id_voyageur

from Dossier D;

