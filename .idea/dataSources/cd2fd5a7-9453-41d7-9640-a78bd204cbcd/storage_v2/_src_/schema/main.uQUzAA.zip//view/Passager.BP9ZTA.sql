CREATE VIEW Passager (Id_passager, nom, prenom, email, telephone)
As
select passenger.id_voyageur, passenger.nom, passenger.prenom,
       MAX (passenger.email) as Email, MAX (passenger.telephone) as telephone

    from (Select V.id_voyageur, nom, prenom,
case C.methode
when 'mail' then C.valeur
else null
end
as email,
case C.methode
when 'telephone' then C.valeur
else null
end
as telephone
from Voyageur V join Contact C on V.id_voyageur = C.id_voyageur) as passenger group by id_voyageur;

